use capstone_project;

select * from capstone_project;

select distinct Country, sum(Units_Sold) from capstone_project group by Country;

select distinct ï»¿Segment, sum(Manufacturing_Price) as Manufacturing_cost, sum(Sale_Price) as Sale_Price,
 round(sum(Profit)) as Total_Profit from capstone_project group by ï»¿Segment order by  Total_Profit asc ;
-- Q4























